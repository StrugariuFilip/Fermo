<?php
$servername = "server39.web-hosting.com";
$username = "fermddgw_Filip";
$password = "Deltaplan2006";
$database = "fermddgw_register";

$con = mysqli_connect($servername, $username, $password, $database);

$database2 = "fermddgw_Oferte";
$con2 = mysqli_connect($servername, $username, $password, $database2);

$database3 = "fermddgw_chat";
$con3 = mysqli_connect($servername, $username, $password, $database3);
?>
<html>

</html>